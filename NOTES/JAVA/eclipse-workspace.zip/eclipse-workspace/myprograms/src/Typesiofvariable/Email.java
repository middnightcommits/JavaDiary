package Typesiofvariable;

public class Email 
{
	public void email()
	{
		String emm="vishvabooi4@gmail.com"; //local variable is declared inside the method
		System.out.println(emm);
	}
	public static void main(String[] args)
	{
		Email a=new Email();
		a.email();
	}

}

