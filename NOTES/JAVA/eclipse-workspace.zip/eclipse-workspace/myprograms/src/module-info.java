/**
 * 
 */
/**
 * 
 */
module myprograms {
	requires java.sql;
}