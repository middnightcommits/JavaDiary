package Logical_programs;
public class sqrt
{
	public static void main(String[] args)
	{
		for(int i=0; i<=100; i++)
		{
			System.out.println(i*i+"");
		}
	}

}
