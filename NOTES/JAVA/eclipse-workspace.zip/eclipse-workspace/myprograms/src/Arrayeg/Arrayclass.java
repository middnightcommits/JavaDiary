package Arrayeg;
public class Arrayclass
{
	public static void main(String[] args)
	{
		int arr[] =
		{ 33, 34, 35 };
		for (int i : arr)
		{
			System.out.println(i);
		}
	}
}
