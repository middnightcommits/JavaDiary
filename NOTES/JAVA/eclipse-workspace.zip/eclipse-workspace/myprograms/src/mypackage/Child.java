package mypackage;

public class Child 
{
	public static void main(String[] args)
	{
		Parent obj=new Parent();
		obj.empl(123,"hello");
	}

}
