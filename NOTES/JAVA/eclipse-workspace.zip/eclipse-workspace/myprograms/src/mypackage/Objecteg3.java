package mypackage;
public class Objecteg3 {
	final int x=5; //instance variable

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Objecteg3 obj=new Objecteg3();		
		obj.x=40;
		System.out.println(obj.x);

	}
}
