package mypackage;
public class Ascii
{
	public static void main(String[] args)
	{
		char a='d';
		int b=(int)a;
		System.out.println(b);
	}
	

}
