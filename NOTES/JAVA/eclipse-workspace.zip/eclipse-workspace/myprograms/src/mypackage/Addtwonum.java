package mypackage;

public class Addtwonum {
	static void add(int a, int b)
	{
		System.out.println("C="+(a+b));
	}
	public static void main(String[] args)
	{
		
		//Addtwonum a=new Addtwonum(); this is how we give normally
		//a.add(10, 20);
		add(5,10);
		
	}
	

}
