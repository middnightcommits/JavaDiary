package mypackage;

public class Eg1
{

}
