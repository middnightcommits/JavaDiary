package Logical_programs;
import java.util.Scanner;
public class Fibonacce
{
	public static void main(String[] args)
	{
		Scanner scan=new Scanner(System.in);
		int a=scan.nextInt();
		int[] b=new int[a];
		b.append(1);
		
		
	}
}
