package mypackage;

public class Sample2 {
	public static void main(String[] args)
	{
		Sampleobject s=new Sampleobject();
		System.out.println(s.y);
	}

}
