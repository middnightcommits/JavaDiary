package Arrayeg;
public class Diamond
{
	int arr[][]=new int[]

}
