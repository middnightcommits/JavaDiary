package mypackage;

public class print1_10_without_for
{
public static void main(String[] args)
{
	int i=0;
	while(i<10)
		{
		i++;
		System.out.println(i);
		}
}
}
