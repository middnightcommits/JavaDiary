package mypackage;
public class Objecteg2 {
	int x=5; //instance variable

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Javaobject obj=new Javaobject();		
		obj.x=40;
		System.out.println(obj.x);

	}
}
