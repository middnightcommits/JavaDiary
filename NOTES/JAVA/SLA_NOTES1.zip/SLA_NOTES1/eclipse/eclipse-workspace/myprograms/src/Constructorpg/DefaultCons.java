package Constructorpg;
//In constructors, the methods doesn't have return type 
public class DefaultCons
{
	public DefaultCons()
	{
		System.out.println("hi there");
	}

	public static void main(String[] args)
	{
		DefaultCons obj = new DefaultCons();
	}
}
