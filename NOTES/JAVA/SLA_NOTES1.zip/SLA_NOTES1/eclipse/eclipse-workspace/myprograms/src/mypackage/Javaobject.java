package mypackage;

public class Javaobject {
	int x=5; //instance variable

	public static void main(String[] args) {
		System.out.println("hi");
		// TODO Auto-generated method stub
		Javaobject obj=new Javaobject();
		System.out.println(obj.x);

	}

}
