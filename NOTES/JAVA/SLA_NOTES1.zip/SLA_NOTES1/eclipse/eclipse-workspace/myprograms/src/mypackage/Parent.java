package mypackage;

public class Parent{
	public void empl(int empid,String empname)
	{
		System.out.println("empid="+empid+"empname="+empname);
	}
	
	public static void main(String[] args) 
	{
		
	}

}
